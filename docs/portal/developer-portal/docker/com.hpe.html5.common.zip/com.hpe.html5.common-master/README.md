# com.hpe.html5.common
common html5 plugin for publishing to HPE Support Center. Currently tested with DITA-OT v3.6.0, v3.7.0 and v3.7.2

The basic command for building is:

```
dita --input=*input-file* --format=HPEscHtml5
```


## Built in extension points

- **dita.xsl.html5.hpe** : extension point for overriding xsl for topic creation. Most of these overrides should be contributed directly to the common plugin for all groups to use. There may be corner cases where html needs to be formatted differently for a group leveraging the common plugin and it can be added here. This plugin can also be used for an interem solution before the common plugin is ready to add the customization. *(NOTE: It is highly discouraged to use this extension for production purposes as overrides will cause output inconsistency and limit the ability to upgrade to the latest common plugin. Please consider contributing your requirements to the common plugin instead.)*

- **dita.xsl.html5.hpe.cover** : override cover. *(NOTE: It is highly discouraged to use this extension for production purposes as overrides will cause output inconsistency and limit the ability to upgrade to the latest common plugin. Please consider contributing your requirements to the common plugin instead.)*

- **depend.HPEscHTML5.pre** : extenstion point for running an ant target before the parameter initialization. This would be a good place to add custom logic when setting ant or xslt parameters.

- **depend.HPEscHTML5.post** : extenstion point for running a ant target after the html is created. This may be an upload service to HPESC or special post processing to the html files for a particular group.

- **dita.xsl.html5.hpe.resources** : temporary extention point for overriding building of resources.json. Currently Ezmeral content limits registering resourceids to topics with appid="\*" and appname="tcaas". KM registers all resourceid elements that have an id or appid attribute specified regardless of the appname attribute.

## DITA command custom parameters (default value in bold)

- (not yet created) **hpesc.resourceid.file.name** \[yes|**no**\] Feature for converting topics with resourceid to file name.

- **topicpull.title.prefix** \[YES|**NO**\] Add prefix to the output text generated for args.(figure|table)link.style=TITLE

## Required plugins

This plugin requires following plugins.

- https://github.hpe.com/hpe/com.hpe.ditacommon (rev 4e424d4)

## Recommended 3rd party plugins

This plugin is tested with following HTML5 extension plugins.

- https://github.com/dita-ot/org.dita.html5.dublin-core (release 3.6.0)

- https://github.com/oxygenxml/dita-media-support (rev b2b049e)

## Topic xsl customizations

### map support for default index.html page

map/title - title of publication

map/topicmeta/shortdesc - Short description of publication

map/topicmeta/data\[\@name="edition"]/\@value or map/topicmeta/data\[\@name="edition"] - publication edition (\@value takes priority if exists)

map/topicmeta/data\[\@name="pubsnumber"]/\@value - publication part number

map/topicref\[\@outputclass="hpe_notice"\] - topics pulled in for index.html content.

### bookmap support for default index.html page

booktitle/mainbooktitle - Primary title used on page

booktitle/booktitlealt - Each one will display below the mainbooktitle

boometa/shortdesc - Short description of publication

bookmeta/othermeta/bookid/bookpartno - publication part number

bookmeta/othermeta/bookid/bookpartno - publication edition

bookmeta/othermeta/bookrights/copyrfirst - first copyright date

bookmeta/othermeta/bookrights/copyrlast - last copyright date

bookmeta/othermeta/bookrights/bookowner/organization - in most cases will be "Hewlett Packard Enterprise Development LP"

backmatter/notices - each notices topic will be included in the index.html in order.


### Table footnotes are collected and displayed at the bottom of each table instead of combined at the end of the topic.

- rel-links.xsl
- tables.xsl
- topic.xsl

### related links are listed in a single "Related information" header vs the default task/glossenry/concept/reference headers

- rel-links.xsl

### Adding github graphic to links

xrefs and links that begin with https://github.com will get a "github-link" class assigned. The CSS will then be able to dynamically add the image.

- rel-links.xsl
