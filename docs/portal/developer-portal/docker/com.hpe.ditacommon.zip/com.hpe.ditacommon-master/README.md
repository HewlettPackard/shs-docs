# com.hpe.ditacommon
org.dita.base plugin extension for HPE DITA-OT environment. Currently tested with DITA-OT v3.7.3 and v3.7.4

This plugin changes org.dita.base plugin behavior for HPE needs, and that may affect to all transtypes.

## Customization from plane org.dita.base implementation

### Generated text (gentext)

- Modified gentext and its translation for HPE business needs
- Supplies addtional gentext required by HPE HTML5 common plugin (https://github.hpe.com/hpe/com.hpe.html5.common)

### HPE alternative of Preprocess2

- Supplies preprocess2-hpe task as an alternative of preprocess2, and that allows each plugin to choose preferred preprocess
- Enables resourceid-based file renaming by default
- Better @copy-to processing than standard preprocess2
- Better @chunk="to-content" processing than standard preprocess2
  https://github.com/dita-ot/dita-ot/issues/3514
  **Limitation:** If @chunk="to-content" is set to map root, preprocess2-hpe try to rename it to $\{args.html5.toc\} or $\{args.markdown.toc\}, and links will be updated appropreately.  However, output topic file name is still hash.  To workaround easy, preprocess2-hpe provides utility task, "postprocess-hpe.rename.root-chunk.topic".  Run the task in transtype plugins to rename hash to specified file name, after hash topic would be generated.  Also, transtype plugins should be responsible to not generate another TOC file redundantly.

### Single HTML/Markdown output replaces TOC file (prepreprocess2-hpe only)

- See "**Limitation:**" above.

### Look-ahead file renaming implementation (prepreprocess2-hpe only)

- Replaces deprecated copy-to-based file renaming by resourceid-based one
- Only available with preprocess2-hpe
- Current implementation only supports format of: <resourceid appname="HTML" appid=*"file_name"*>
